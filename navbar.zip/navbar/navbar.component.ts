import { Component } from '@angular/core';
import { HeroComponent } from '../hero/hero.component';

@Component({
  selector: 'app-navbar',
  standalone: true,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  imports:[HeroComponent]
})
export class NavbarComponent {
  
  public toggleClass()
  {
    document.querySelector(".nav-links")?.classList.toggle("mobile-menu");
  }

}
